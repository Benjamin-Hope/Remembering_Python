# here we will look over the shell utilities. There are used to manipulate files and directories

import os
from os import path
import shutil  # this is the shell utilities lib
from shutil import make_archive  # this is used to make a zip file


def main():
    if path.exists("mytext.txt"):
        # lets do a copy of the file
        src = path.realpath("mytext.txt")
        # 1st we should back a backup of the file, and define the destination
        dst = src + ".bak"
        # 2nd we should copy the file
        shutil.copy(src, dst)  # this copies the file into a backup destination

        # renaming the file:
        os.rename("mytext.txt.bak", "newfile_backup.txt")

        # lets make a zip of this directory
        # -- here '[0]' is used to get the path only and not the full scr
        dir = path.split(path.realpath("newfile_backup.txt"))[0]
        # -- this creates a zip file of the directory, the first parameter is the name of the archive
        shutil.make_archive("my_zipper", "zip", dir)


if __name__ == "__main__":
    main()
